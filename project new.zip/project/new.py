from plantuml import PlantUML

uml_code = """
@startuml

class Student {
    - name: String
    - GPA: float
    - skills: List<String>
    + calculateScore(): float
    + updateSkills(newSkills: List<String>): void
}

class Company {
    - name: String
    - industry: String
    - requirements: List<String>
    + evaluateCandidate(student: Student): boolean
    + updateRequirements(newRequirements: List<String>): void
}

class PlacementPredictionModel {
    + trainModel(): void
    + predictPlacement(student: Student, company: Company): boolean
    + evaluateModel(): float
}

Student -- Company : applies to
@enduml
"""

# Generate the image
with PlantUML() as plantuml:
    url = plantuml.processes_string(uml_code)

print(f"UML Diagram URL: {url}")
