import numpy as np
import pandas as pd
from PIL import Image
import streamlit as st
import pickle

# Load the trained model
lg = pickle.load(open('placement.pkl','rb'))

# Web app title and description
st.title("Job Placement Prediction Model")
st.write("""
This web app predicts whether a person will be placed in a job based on certain features.
Please enter the required features separated by commas.
""")

# Display an image
img = Image.open('Job-Placement-Agency.jpg')
st.image(img, width=650, caption='Image source: Your Agency')

# Input fields for name and college name
name = st.text_input("Enter your Name")
college_name = st.text_input("Enter your College Name")

# Input features
input_text = st.text_input("Enter the Details (comma-separated)")

if input_text:
    try:
        # Convert input to a numpy array
        input_list = input_text.split(',')
        np_df = np.asarray(input_list, dtype=float)

        # Make predictions
        prediction = lg.predict(np_df.reshape(1, -1))

        # Display prediction result
        if prediction[0] == 1:
            st.success("Prediction: This person is placed.")
        else:
            st.error("Prediction: This person is not placed.")
            
            # Suggest courses
            st.subheader("Recommended Courses")
            st.write("Based on our analysis, we recommend the following courses to improve your skills and increase your chances of placement:")
            st.markdown("- [A to Z DSA](https://example.com/dsa)")
            st.markdown("- [Full Stack Web Development](https://example.com/web-development)")
            # Add more courses as needed with Markdown syntax

    except ValueError:
        st.error("Please enter valid numeric values separated by commas.")

# Additional Features Section
st.sidebar.title("Courses")
st.sidebar.write("""
Empower yourself with our top-rated courses:
- [DSA](https://example.com/dsa)
- [Web Development: HTML, CSS, JavaScript](https://example.com/web-development)
- ...
""")

# About Section
st.sidebar.title("About")
st.sidebar.write("""
This web app is a simple job placement prediction model. It takes input features and predicts whether a person will be placed in a job or not.
""")
